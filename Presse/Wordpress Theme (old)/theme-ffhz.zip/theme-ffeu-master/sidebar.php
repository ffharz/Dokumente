        <div id="linkblock">
            <h3>Links</h3>
            <ul>                
              <!--  <li><a href="http://freifunk.net/" target="_blank">Freifunk.net</a></li>
                <li><a href="http://de.netmeterproject.com/wifi" target="_blank">Abdeckungskarten</a></li> -->
                <?php wp_nav_menu( array( 'theme_location' => 'secondary' ) ); ?>
            </ul>
        </div>
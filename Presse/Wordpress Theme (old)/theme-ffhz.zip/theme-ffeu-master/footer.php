<?php wp_footer(); ?> <div id="footer">
            <a href="/impressum">Impressum</a>
        </div>
    </div>
    <!--Creative Commons-->
    <div id="cc">
        <a rel="license" href="http://creativecommons.org/licenses/by/4.0/deed.de">
            <img alt="Creative Commons Lizenzvertrag" style="border-width: 0" src="/wp-content/themes/theme-ffeu-master/images/88x31.png" />
        </a>
    </div>
    <!-- <div id="cancel">
        <div id="box">
            <h1>Freifunk Harz ist gestorben.</h1>
            <small>* 14.02.2014 &nbsp; &nbsp;&nbsp; &dagger; 18.02.2014</small>
        </div>
    </div> -->
</body>
</html>